function r = homework2(t)

r=[cos(t) -sin(t) 0;sin(t) cos(t) 0; 0 0 1;];
