theta = 0
x1 = theta
x2 = diff(theta)
% assigns the variables names
% x1diff = diff(integral(x2,x))
help ode45
