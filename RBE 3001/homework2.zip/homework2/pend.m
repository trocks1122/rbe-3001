function xdot = pend(t,x)
g = 32;%ft/s^2
L = 2; %ft
xdot = [0;0];
xdot(1) = diff(integral(x2,x))
xdot(2) = diff(integral(x2,x))
end